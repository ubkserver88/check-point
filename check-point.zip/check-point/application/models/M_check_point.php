<?php
class M_check_point extends CI_Model
{
    function get_all_data(){
		$hsl=$this->db->query("SELECT * FROM data_check_point");
		return $hsl;	
	}

    function simpan_data($nama_pemeriksa, $sesi_check_point, $area, $photo_bukti)
    {
        $hsl = $this->db->query("INSERT INTO data_check_point (nama_pemeriksa,sesi_check_point,area,photo_bukti) VALUES ('$nama_pemeriksa','$sesi_check_point','$area','$photo_bukti')");
        return $hsl;
    }
}
